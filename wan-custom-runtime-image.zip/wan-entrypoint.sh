#!/bin/bash
set -euo pipefail

comfy_dir=/workspace/runpod-slim/ComfyUI
if [ -d "$comfy_dir" ]; then
  mkdir -p "$comfy_dir/custom_nodes/ComfyUI-GGUF"
  mkdir -p "$comfy_dir/custom_nodes/comfyui-videohelpersuite"
  mkdir -p "$comfy_dir/custom_nodes/wan-model-provisioner"
  rsync -a --delete /opt/wan-custom-nodes/ComfyUI-GGUF/ "$comfy_dir/custom_nodes/ComfyUI-GGUF/"
  rsync -a --delete /opt/wan-custom-nodes/comfyui-videohelpersuite/ "$comfy_dir/custom_nodes/comfyui-videohelpersuite/"
  rsync -a --delete /opt/wan-custom-nodes/wan-model-provisioner/ "$comfy_dir/custom_nodes/wan-model-provisioner/"
fi
exec /start.sh "$@"
