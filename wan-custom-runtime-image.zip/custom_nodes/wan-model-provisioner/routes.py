"""ComfyUI HTTP routes for the sealed Wan model provisioner."""
from aiohttp import web
from server import PromptServer

from .provision_core import ARTIFACTS, Provisioner


PROVISIONER = Provisioner()


@PromptServer.instance.routes.get("/wan_provision/status/{artifact_id}")
async def wan_provision_status(request):
    artifact_id = request.match_info.get("artifact_id")
    if artifact_id not in ARTIFACTS:
        return web.json_response({"error": "unknown artifact_id"}, status=404)
    return web.json_response(PROVISIONER.status(artifact_id))


@PromptServer.instance.routes.post("/wan_provision/start")
async def wan_provision_start(request):
    try:
        payload = await request.json()
    except Exception:
        return web.json_response({"error": "invalid json"}, status=400)
    if type(payload) is not dict or set(payload) != {"artifact_id"} or \
            payload.get("artifact_id") not in ARTIFACTS:
        return web.json_response({"error": "invalid artifact identity"}, status=400)
    result = PROVISIONER.start(payload["artifact_id"])
    return web.json_response(result, status=202 if result["accepted"] else 409)


NODE_CLASS_MAPPINGS = {}
NODE_DISPLAY_NAME_MAPPINGS = {}
