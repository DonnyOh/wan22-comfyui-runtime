"""Sealed Wan model registry and atomic download implementation."""
from __future__ import annotations

import hashlib
import os
import threading
import urllib.request
from pathlib import Path


MODEL_ROOT = Path("/workspace/runpod-slim/ComfyUI/models")
ARTIFACTS = {
    "unet_low_noise": {
        "folder_key": "diffusion_models",
        "filename": "wan2.2_i2v_low_noise_14B_Q8_0.gguf",
        "size_bytes": 15406608896,
        "sha256": "029c7adc74de4f7804905c5e4fb9335d0862cd2fc37191df526aeac13b64425e",
        "url": "https://huggingface.co/bullerwins/Wan2.2-I2V-A14B-GGUF/resolve/b1b0ef5e7677f9ad661fb15652c070077fd728e3/wan2.2_i2v_low_noise_14B_Q8_0.gguf",
    },
    "unet_high_noise": {
        "folder_key": "diffusion_models",
        "filename": "wan2.2_i2v_high_noise_14B_Q8_0.gguf",
        "size_bytes": 15406608896,
        "sha256": "619a66032c28e1b27882dfccc0bf93e51edb1491e8d4e4c6f291726abe4de8aa",
        "url": "https://huggingface.co/bullerwins/Wan2.2-I2V-A14B-GGUF/resolve/b1b0ef5e7677f9ad661fb15652c070077fd728e3/wan2.2_i2v_high_noise_14B_Q8_0.gguf",
    },
    "text_encoder": {
        "folder_key": "text_encoders",
        "filename": "umt5_xxl_fp8_e4m3fn_scaled.safetensors",
        "size_bytes": 6735906897,
        "sha256": "c3355d30191f1f066b26d93fba017ae9809dce6c627dda5f6a66eaa651204f68",
        "url": "https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/dfcea77bcf258496e20c69cd84e8e8e41909bb3b/split_files/text_encoders/umt5_xxl_fp8_e4m3fn_scaled.safetensors",
    },
    "vae": {
        "folder_key": "vae",
        "filename": "wan_2.1_vae.safetensors",
        "size_bytes": 253815318,
        "sha256": "2fc39d31359a4b0a64f55876d8ff7fa8d780956ae2cb13463b0223e15148976b",
        "url": "https://huggingface.co/Comfy-Org/Wan_2.1_ComfyUI_repackaged/resolve/dfcea77bcf258496e20c69cd84e8e8e41909bb3b/split_files/vae/wan_2.1_vae.safetensors",
    },
    "frame_interpolation": {
        "folder_key": "frame_interpolation",
        "filename": "rife_v4.25_heavy.safetensors",
        "size_bytes": 86669816,
        "sha256": "40aa1838b91531f829caaac026f40d9d2e2f1eb12b65d1d6029a58ae4c703191",
        "url": "https://huggingface.co/Comfy-Org/frame_interpolation/resolve/4af58fac5bafcaf513d67119fb90501f5b115a4b/frame_interpolation/rife_v4.25_heavy.safetensors",
    },
}


class Provisioner:
    """One-process controller for the fixed model registry."""

    def __init__(self, root=MODEL_ROOT, opener=None):
        self.root = Path(root)
        self.opener = opener or urllib.request.urlopen
        self._lock = threading.Lock()
        self._states = {}
        self._active = None

    @staticmethod
    def _artifact(artifact_id):
        if type(artifact_id) is not str or artifact_id not in ARTIFACTS:
            raise ValueError("unknown artifact_id")
        return ARTIFACTS[artifact_id]

    def _paths(self, artifact_id):
        item = self._artifact(artifact_id)
        final = self.root / item["folder_key"] / item["filename"]
        part = final.with_name(final.name + ".part." + item["sha256"])
        return item, final, part

    @staticmethod
    def _identity(artifact_id, item):
        return {"schema_version": 1, "artifact_id": artifact_id,
                "folder_key": item["folder_key"], "filename": item["filename"],
                "size_bytes": item["size_bytes"], "sha256": item["sha256"]}

    @staticmethod
    def _verify(path, item):
        if not path.is_file() or path.is_symlink():
            return False
        if path.stat().st_size != item["size_bytes"]:
            return False
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
                digest.update(block)
        return digest.hexdigest() == item["sha256"]

    def status(self, artifact_id):
        item, final, part = self._paths(artifact_id)
        identity = self._identity(artifact_id, item)
        with self._lock:
            state = dict(self._states.get(artifact_id, {}))
        if state.get("status") in {
                "queued", "downloading", "verifying", "completed", "error"}:
            observed = final if state.get("status") in {"verifying", "completed"} else part
            downloaded = observed.stat().st_size if observed.is_file() else 0
            return {**identity, **state, "downloaded": downloaded,
                    "total": item["size_bytes"]}
        if final.exists():
            with self._lock:
                if self._active is not None:
                    return {**identity, "status": "busy", "downloaded": 0,
                            "total": item["size_bytes"]}
                self._active = artifact_id
                self._states[artifact_id] = {"status": "verifying", "error": None}
            threading.Thread(target=self._verify_existing,
                             args=(artifact_id, item, final), daemon=True,
                             name="wan-verify-" + artifact_id).start()
            return {**identity, "status": "verifying", "error": None,
                    "downloaded": final.stat().st_size if final.is_file() else 0,
                    "total": item["size_bytes"]}
        if part.exists():
            return {**identity, "status": "error", "error": "stale_partial",
                    "downloaded": part.stat().st_size if part.is_file() else 0,
                    "total": item["size_bytes"]}
        return {**identity, "status": "missing", "downloaded": 0,
                "total": item["size_bytes"]}

    def _verify_existing(self, artifact_id, item, final):
        try:
            valid = self._verify(final, item)
            with self._lock:
                self._states[artifact_id] = {
                    "status": "completed" if valid else "error",
                    "error": None if valid else "final_integrity_mismatch",
                    "size_verified": valid, "hash_verified": valid}
        finally:
            with self._lock:
                if self._active == artifact_id:
                    self._active = None

    def start(self, artifact_id):
        item, final, part = self._paths(artifact_id)
        current = self.status(artifact_id)
        if current["status"] == "completed":
            return {"accepted": False, "artifact_id": artifact_id,
                    "status": "completed"}
        if current["status"] != "missing":
            return {"accepted": False, "artifact_id": artifact_id,
                    "status": current["status"]}
        with self._lock:
            if self._active is not None:
                return {"accepted": False, "artifact_id": artifact_id,
                        "status": "busy"}
            self._active = artifact_id
            self._states[artifact_id] = {"status": "queued", "error": None}
        worker = threading.Thread(target=self._download,
                                  args=(artifact_id, item, final, part),
                                  daemon=True, name="wan-model-" + artifact_id)
        worker.start()
        return {"accepted": True, "artifact_id": artifact_id,
                "status": "queued"}

    def _download(self, artifact_id, item, final, part):
        try:
            final.parent.mkdir(parents=True, exist_ok=True)
            if part.exists():
                raise RuntimeError("stale_partial")
            with self._lock:
                self._states[artifact_id] = {"status": "downloading", "error": None}
            request = urllib.request.Request(item["url"], headers={
                "Accept": "application/octet-stream",
                "User-Agent": "wan-model-provisioner/1"})
            digest = hashlib.sha256()
            size = 0
            with self.opener(request, timeout=60) as response, part.open("xb") as output:
                for block in iter(lambda: response.read(8 * 1024 * 1024), b""):
                    size += len(block)
                    if size > item["size_bytes"]:
                        raise RuntimeError("download_too_large")
                    digest.update(block)
                    output.write(block)
                output.flush()
                os.fsync(output.fileno())
            if size != item["size_bytes"]:
                raise RuntimeError("size_mismatch")
            if digest.hexdigest() != item["sha256"]:
                raise RuntimeError("sha256_mismatch")
            os.replace(part, final)
            with self._lock:
                self._states[artifact_id] = {"status": "completed", "error": None,
                                             "size_verified": True,
                                             "hash_verified": True}
        except Exception as exc:
            label = str(exc) if str(exc) in {"stale_partial", "download_too_large",
                "size_mismatch", "sha256_mismatch"} else "download_failed"
            with self._lock:
                self._states[artifact_id] = {"status": "error", "error": label}
        finally:
            with self._lock:
                if self._active == artifact_id:
                    self._active = None
